package com.cobabuat.gemdev.view.bermain

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.cobabuat.gemdev.databinding.ActivityBermainHomeBinding
import com.cobabuat.gemdev.model.UserPreference
import com.cobabuat.gemdev.view.belajar.BelajarSatuActivity
import com.cobabuat.gemdev.view.bermain.levelone.LevelOneActivity
import com.cobabuat.gemdev.view.bermain.levelthree.LevelThreeActivity
import com.cobabuat.gemdev.view.bermain.leveltwo.LevelTwoActivity
import com.cobabuat.gemdev.view.main.MainActivity
import com.cobabuat.gemdev.view.main.MainViewModel
import com.cobabuat.gemdev.view.other.BackgroundMusicService
import com.cobabuat.gemdev.view.other.ViewModelFactory
import com.cobabuat.gemdev.view.welcome.WelcomeActivity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
class BermainHomeActivity : AppCompatActivity() {
    private lateinit var binding : ActivityBermainHomeBinding
    private lateinit var mainViewModel: MainViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBermainHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupAction()
        setupView()
        setupViewModel()
        observePoints()
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setupViewModel() {
        mainViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreference.getInstance(dataStore))
        )[MainViewModel::class.java]

        mainViewModel.getUser().observe(this) { user ->
            if (user.isLogin) {
                binding.tvUsername.text = user.name
            } else {
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            }
        }

    }

    private fun observePoints() {
        val tvPoints = binding.tvPoints
        val dataStore = applicationContext.dataStore
        val userPreference = UserPreference.getInstance(dataStore)

        lifecycleScope.launch {
            userPreference.getUser().collect { user ->
                tvPoints.text = user.points.toString()
            }
        }

    }

    private fun setupAction() {
        binding.btnBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        binding.btnLogout.setOnClickListener {
            // Stop the background music service
            stopService(Intent(this, BackgroundMusicService::class.java))
            // Then logout
            mainViewModel.logout()
        }
        binding.levelOne.setOnClickListener {
            val intent = Intent(this, LevelOneActivity::class.java)
            startActivity(intent)
        }
        setupLevelTwoButton().let {
            binding.levelTwo.setOnClickListener {
                setupLevelTwoButton()
            }
        }

        setupLevelThreeButton().let {
            binding.levelThree.setOnClickListener {
                setupLevelThreeButton()
            }
        }

    }

    private fun setupLevelTwoButton() {
        lifecycleScope.launch {
            val userPreference = UserPreference.getInstance(dataStore)
            val user = userPreference.getUser().first()
            if (user.points >= 500) {
                binding.ivLockedTwo.visibility = View.GONE
            } else {
                binding.ivLockedTwo.visibility = View.VISIBLE
            }
            binding.levelTwo.setOnClickListener {
                if (user.points < 500) {
                    // Tampilkan peringatan jika poin kurang dari 500
                    showAlertLevelTwo()
                } else {
                    // Lanjutkan ke LevelTwoActivity jika poin cukup
                    val intent = Intent(this@BermainHomeActivity, LevelTwoActivity::class.java)
                    startActivity(intent)
                }
            }
        }
    }

    private fun showAlertLevelTwo() {
        AlertDialog.Builder(this)
            .setTitle("Peringatan")
            .setMessage("Kamu Membutuhkan point 500 untuk masuk ke tahap ini")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun setupLevelThreeButton() {
        lifecycleScope.launch {
            val userPreference = UserPreference.getInstance(dataStore)
            val user = userPreference.getUser().first()

            if (user.points >= 2000) {
                binding.ivLockedThree.visibility = View.GONE
            } else {
                binding.ivLockedThree.visibility = View.VISIBLE
            }

            binding.levelThree.setOnClickListener {
                if (user.points < 2000) {
                    // Tampilkan peringatan jika poin kurang dari 500
                    showAlertLevelThree()
                } else {
                    val intent = Intent(this@BermainHomeActivity, LevelThreeActivity::class.java)
                    startActivity(intent)
                }
            }
        }
    }

    private fun showAlertLevelThree() {
        AlertDialog.Builder(this)
            .setTitle("Peringatan")
            .setMessage("Kamu Membutuhkan point 2000 untuk masuk ke tahap ini")
            .setPositiveButton("OK", null)
            .show()
    }

}