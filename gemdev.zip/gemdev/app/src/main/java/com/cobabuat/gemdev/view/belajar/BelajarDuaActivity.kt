package com.cobabuat.gemdev.view.belajar

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.cobabuat.gemdev.R
import com.cobabuat.gemdev.databinding.ActivityBelajarDuaBinding
import com.cobabuat.gemdev.view.main.MainActivity

class BelajarDuaActivity : AppCompatActivity() {
    private lateinit var binding : ActivityBelajarDuaBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBelajarDuaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        navigation()
    }

    private fun navigation() {
        binding.ivArrowLeft.setOnClickListener {
            val intent = Intent(this, BelajarSatuActivity::class.java)
            startActivity(intent)
        }
        binding.ivArrowRight.setOnClickListener {
            val intent = Intent(this, BelajarTigaActivity::class.java)
            startActivity(intent)
        }
        binding.ivCloseButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}