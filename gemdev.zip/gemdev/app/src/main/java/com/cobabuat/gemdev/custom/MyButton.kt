package com.cobabuat.gemdev.custom

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.Gravity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import com.cobabuat.gemdev.R

class MyButton : AppCompatButton {

    constructor(context: Context) : super(context) {
        init()
    }
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init()
    }
    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init()
    }

    private fun init() {
        val strokeWidth = resources.getDimensionPixelSize(R.dimen.default_stroke_width) // e.g., 2dp
        val strokeColor = ContextCompat.getColor(context, R.color.blue_700) // e.g., Color.BLUE or your custom color
        val fillColor = ContextCompat.getColor(context, android.R.color.white)
        val roundedCorner = resources.getDimension(R.dimen.default_corner_radius) // e.g., 8dp

        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(fillColor)
            cornerRadius = roundedCorner
            setStroke(strokeWidth, strokeColor)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val txtColor = ContextCompat.getColor(context, R.color.blue_700)
        setTextColor(txtColor)
        textSize = 12f
        gravity = Gravity.CENTER
    }
}
