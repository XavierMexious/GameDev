package com.cobabuat.gemdev.view.signup

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cobabuat.gemdev.model.UserModel
import com.cobabuat.gemdev.model.UserPreference

import kotlinx.coroutines.launch

class SignupViewModel(private val pref: UserPreference) : ViewModel() {
    fun saveUser(user: UserModel) {
        viewModelScope.launch {
            pref.saveUser(user)
        }
    }
}