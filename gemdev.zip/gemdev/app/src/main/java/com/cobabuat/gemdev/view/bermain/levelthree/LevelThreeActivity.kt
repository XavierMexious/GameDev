package com.cobabuat.gemdev.view.bermain.levelthree

import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Rect
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.lifecycleScope
import com.cobabuat.gemdev.databinding.ActivityLevelOneBinding
import com.cobabuat.gemdev.databinding.ActivityLevelThreeBinding
import com.cobabuat.gemdev.databinding.ActivityLevelTwoBinding
import com.cobabuat.gemdev.model.UserPreference
import com.cobabuat.gemdev.view.bermain.BermainHomeActivity
import com.cobabuat.gemdev.view.other.BackgroundMusicPlayService
import com.cobabuat.gemdev.view.other.BackgroundMusicService
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.random.Random

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
class LevelThreeActivity : AppCompatActivity() {
    private lateinit var binding : ActivityLevelThreeBinding
    private lateinit var selectedTongSampah: ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLevelThreeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        stopService(Intent(this, BackgroundMusicService::class.java))
        startService(Intent(this, BackgroundMusicPlayService::class.java))
        tongSampah()
        startGame()
        observePoints()
        lifecycleScope.launch {
            checkCollision()
        }
        val tvTimers = binding.tvTimers

        val timer = object: CountDownTimer(15000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                tvTimers.text = (millisUntilFinished / 1000).toString()
            }

            override fun onFinish() {
                tvTimers.text = "0"
                // Set visibility of initial elements to GONE
                binding.ivTempatPoint.visibility = View.GONE
                binding.tvPoints.visibility = View.GONE
                binding.tvTimers.visibility = View.GONE

                // Set visibility of popup elements to VISIBLE
                binding.ivScorePopup.visibility = View.VISIBLE
                binding.tvPointsPopup.visibility = View.VISIBLE
                binding.btnBackPopup.visibility = View.VISIBLE
                binding.btnStartPopup.visibility = View.VISIBLE
                binding.ivGameoverPopup.visibility = View.VISIBLE

                binding.ivTongSampahHijau.setOnTouchListener(null)
                binding.ivTongSampahKuning.setOnTouchListener(null)
                binding.ivTongSampahMerah.setOnTouchListener(null)

                animationSampahPertamaBerhenti()
                animationSampahKeduaBerhenti()
                observePointsFinishGame()
                setupActionAfterFinish()
            }
        }
        timer.start()
    }

    private fun animationSampahPertamaBerhenti() {
        animatorSampahHijau?.let {
            it.cancel()
            binding.ivSampahHijauSatu.translationY = -binding.ivSampahHijauSatu.height.toFloat()
        }
        animatorSampahKuning?.let {
            it.cancel()
            binding.ivSampahKuningSatu.translationY = -binding.ivSampahKuningSatu.height.toFloat()
        }
        animatorSampahMerah?.let {
            it.cancel()
            binding.ivSampahMerahSatu.translationY = -binding.ivSampahMerahSatu.height.toFloat()
        }
    }
    private fun animationSampahKeduaBerhenti() {
        animatorSampahHijauDua?.let {
            it.cancel()
            binding.ivSampahHijauSatu.translationY = -binding.ivSampahHijauSatu.height.toFloat()
        }
        animatorSampahKuningDua?.let {
            it.cancel()
            binding.ivSampahKuningSatu.translationY = -binding.ivSampahKuningSatu.height.toFloat()
        }
        animatorSampahMerahDua?.let {
            it.cancel()
            binding.ivSampahMerahSatu.translationY = -binding.ivSampahMerahSatu.height.toFloat()
        }
    }
    override fun onPause() {
        super.onPause()

        // Jika activity ini tidak lagi aktif, hentikan BackgroundMusicPlayService dan mulai BackgroundMusicService
        stopService(Intent(this, BackgroundMusicPlayService::class.java))
        if (isFinishing) {
            startService(Intent(this, BackgroundMusicService::class.java))
        }
    }

    private suspend fun checkCollision() {
        val tongSampahHijau = binding.ivTongSampahHijau
        val tongSampahKuning = binding.ivTongSampahKuning
        val tongSampahMerah = binding.ivTongSampahMerah
        val sampahHijau = binding.ivSampahHijauSatu
        val sampahKuning = binding.ivSampahKuningSatu
        val sampahMerah = binding.ivSampahMerahSatu


//        Logika Sampah Pertama

        if (tongSampahHijau.boundingRect.contains(sampahHijau.boundingRect)) {
            // Sampah hijau jatuh ke tong sampah hijau, tambahkan 10 poin
            updateUserPoints(15)
            sampahHijau.translationY = -sampahHijau.height.toFloat()  // Reset posisi sampah hijau
        } else if (tongSampahKuning.boundingRect.contains(sampahKuning.boundingRect)) {
            // Sampah kuning jatuh ke tong sampah kuning, tambahkan 10 poin
            updateUserPoints(15)
            sampahKuning.translationY = -sampahKuning.height.toFloat()  // Reset posisi sampah kuning
        } else if (tongSampahMerah.boundingRect.contains(sampahMerah.boundingRect)) {
            // Sampah merah jatuh ke tong sampah merah, tambahkan 10 poin
            updateUserPoints(15)
            sampahMerah.translationY = -sampahMerah.height.toFloat()  // Reset posisi sampah merah
        } else if (tongSampahHijau.boundingRect.contains(sampahKuning.boundingRect) ||
            tongSampahHijau.boundingRect.contains(sampahMerah.boundingRect) ||
            tongSampahKuning.boundingRect.contains(sampahHijau.boundingRect) ||
            tongSampahKuning.boundingRect.contains(sampahMerah.boundingRect) ||
            tongSampahMerah.boundingRect.contains(sampahHijau.boundingRect) ||
            tongSampahMerah.boundingRect.contains(sampahKuning.boundingRect)) {
            // Sampah non-hijau jatuh ke tong sampah hijau, atau sampah non-kuning jatuh ke tong sampah kuning,
            // atau sampah non-merah jatuh ke tong sampah merah, kurangi 5 poin
            updateUserPoints(-30)
            if (sampahHijau.visibility == View.VISIBLE) {
                sampahHijau.translationY = -sampahHijau.height.toFloat()  // Reset posisi sampah hijau
            }
            if (sampahKuning.visibility == View.VISIBLE) {
                sampahKuning.translationY = -sampahKuning.height.toFloat()  // Reset posisi sampah kuning
            }
            if (sampahMerah.visibility == View.VISIBLE) {
                sampahMerah.translationY = -sampahMerah.height.toFloat()  // Reset posisi sampah merah
            }
        }

//        Logika Sampah Kedua
        val sampahHijauDua = binding.ivSampahHijauDua
        val sampahKuningDua = binding.ivSampahKuningDua
        val sampahMerahDua = binding.ivSampahMerahDua

        if (tongSampahHijau.boundingRect.contains(sampahHijauDua.boundingRect)) {
            updateUserPoints(15)
            sampahHijauDua.translationY = -sampahHijauDua.height.toFloat()
        } else if (tongSampahKuning.boundingRect.contains(sampahKuningDua.boundingRect)) {
            updateUserPoints(15)
            sampahKuningDua.translationY = -sampahKuningDua.height.toFloat()
        } else if (tongSampahMerah.boundingRect.contains(sampahMerahDua.boundingRect)) {
            updateUserPoints(15)
            sampahMerahDua.translationY = -sampahMerahDua.height.toFloat()
        }

        // Logika untuk sampah baru jatuh ke tong sampah yang salah
        else if (tongSampahHijau.boundingRect.contains(sampahKuningDua.boundingRect) ||
            tongSampahHijau.boundingRect.contains(sampahMerahDua.boundingRect) ||
            tongSampahKuning.boundingRect.contains(sampahHijauDua.boundingRect) ||
            tongSampahKuning.boundingRect.contains(sampahMerahDua.boundingRect) ||
            tongSampahMerah.boundingRect.contains(sampahHijauDua.boundingRect) ||
            tongSampahMerah.boundingRect.contains(sampahKuningDua.boundingRect)) {
            updateUserPoints(-30)
            sampahHijauDua.translationY = -sampahHijauDua.height.toFloat()
            sampahKuningDua.translationY = -sampahKuningDua.height.toFloat()
            sampahMerahDua.translationY = -sampahMerahDua.height.toFloat()
        }
    }



    private val View.boundingRect: Rect
        get() {
            val rect = Rect()
            getGlobalVisibleRect(rect)
            return rect
        }

    private suspend fun updateUserPoints(points: Int) {
        val userPreference = UserPreference.getInstance(dataStore)
        val user = userPreference.getUser().first()
        user.points += points
        userPreference.saveUser(user)
    }

    private var animatorSampahHijau: ObjectAnimator? = null
    private var animatorSampahKuning: ObjectAnimator? = null
    private var animatorSampahMerah: ObjectAnimator? = null

    private var animatorSampahHijauDua: ObjectAnimator? = null
    private var animatorSampahKuningDua: ObjectAnimator? = null
    private var animatorSampahMerahDua: ObjectAnimator? = null

    private fun animateFallingObject(imageView: ImageView, duration: Long): ObjectAnimator {
        val screenHeight = Resources.getSystem().displayMetrics.heightPixels
        imageView.translationY = -imageView.height.toFloat()
        return ObjectAnimator.ofFloat(imageView, "translationY", screenHeight.toFloat()).apply {
            this.duration = duration
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.RESTART
            start()
        }
    }

    private fun startGame() {
        val sampahHijau = binding.ivSampahHijauSatu
        val sampahKuning = binding.ivSampahKuningSatu
        val sampahMerah = binding.ivSampahMerahSatu

        val sampahHijauDua = binding.ivSampahHijauDua
        val sampahKuningDua = binding.ivSampahKuningDua
        val sampahMerahDua = binding.ivSampahMerahDua

        animatorSampahHijau = animateFallingObject(sampahHijau, 100)
        animatorSampahKuning = animateFallingObject(sampahKuning, 500)
        animatorSampahMerah = animateFallingObject(sampahMerah, 200)

        animatorSampahHijauDua = animateFallingObject(sampahHijauDua, 300)
        animatorSampahKuningDua = animateFallingObject(sampahKuningDua, 800)
        animatorSampahMerahDua = animateFallingObject(sampahMerahDua, 1000)
    }


    private fun observePoints() {
        val tvPoints = binding.tvPoints
        val dataStore = applicationContext.dataStore
        val userPreference = UserPreference.getInstance(dataStore)

        lifecycleScope.launch {
            userPreference.getUser().collect { user ->
                tvPoints.text = user.points.toString()
            }
        }

    }

    private fun observePointsFinishGame() {
        val tvPoints = binding.tvPointsPopup
        val dataStore = applicationContext.dataStore
        val userPreference = UserPreference.getInstance(dataStore)

        lifecycleScope.launch {
            userPreference.getUser().collect { user ->
                tvPoints.text = user.points.toString()
            }
        }

    }

    private fun setupActionAfterFinish() {
        binding.btnStartPopup.setOnClickListener {
            val intent = Intent(this, LevelThreeActivity::class.java)
            startActivity(intent)
        }

        binding.btnBackPopup.setOnClickListener {
            val intent = Intent(this, BermainHomeActivity::class.java)
            startActivity(intent)
        }
    }

    private fun tongSampah() {
        val tongSampahHijau = binding.ivTongSampahHijau
        val tongSampahKuning = binding.ivTongSampahKuning
        val tongSampahMerah = binding.ivTongSampahMerah

        when (Random.nextInt(3)) {
            0 -> {
                selectedTongSampah = tongSampahHijau
                tongSampahHijau.visibility = View.VISIBLE
                tongSampahKuning.visibility = View.GONE
                tongSampahMerah.visibility = View.GONE
                tongSampahHijau()
            }
            1 -> {
                selectedTongSampah = tongSampahKuning
                tongSampahHijau.visibility = View.GONE
                tongSampahKuning.visibility = View.VISIBLE
                tongSampahMerah.visibility = View.GONE
                tongSampahKuning()
            }
            2 -> {
                selectedTongSampah = tongSampahMerah
                tongSampahHijau.visibility = View.GONE
                tongSampahKuning.visibility = View.GONE
                tongSampahMerah.visibility = View.VISIBLE
                tongSampahMerah()
            }
        }
    }

    private fun tongSampahHijau() {
        val tongSampahHijau = binding.ivTongSampahHijau
        var dX = 0f

        tongSampahHijau.setOnTouchListener { view, motionEvent ->
            when (motionEvent.action) {
                MotionEvent.ACTION_DOWN -> {
                    dX = view.x - motionEvent.rawX
                }
                MotionEvent.ACTION_MOVE -> {
                    view.animate()
                        .x(motionEvent.rawX + dX)
                        .setDuration(0)
                        .start()
                    lifecycleScope.launch {
                        checkCollision()
                    }
                }
                else -> return@setOnTouchListener false
            }
            true
        }
    }

    private fun tongSampahKuning() {
        val tongSampahKuning = binding.ivTongSampahKuning
        var dX = 0f

        tongSampahKuning.setOnTouchListener { view, motionEvent ->
            when (motionEvent.action) {
                MotionEvent.ACTION_DOWN -> {
                    dX = view.x - motionEvent.rawX
                }
                MotionEvent.ACTION_MOVE -> {
                    view.animate()
                        .x(motionEvent.rawX + dX)
                        .setDuration(0)
                        .start()
                    lifecycleScope.launch {
                        checkCollision()
                    }
                }
                else -> return@setOnTouchListener false
            }
            true
        }
    }

    private fun tongSampahMerah() {
        val tongSampahMerah = binding.ivTongSampahMerah
        var dX = 0f

        tongSampahMerah.setOnTouchListener { view, motionEvent ->
            when (motionEvent.action) {
                MotionEvent.ACTION_DOWN -> {
                    dX = view.x - motionEvent.rawX
                }
                MotionEvent.ACTION_MOVE -> {
                    view.animate()
                        .x(motionEvent.rawX + dX)
                        .setDuration(0)
                        .start()
                    lifecycleScope.launch {
                        checkCollision()
                    }
                }
                else -> return@setOnTouchListener false
            }
            true
        }
    }


}